﻿<?php

// PostgreSQL connection parameters
$host = '127.0.0.1';  // or 'localhost'
$port = '5432';
$dbname = 'mcm_database';
$username = 'postgres';
$password = 'postgres';
// $password = 'password';

try {
    // PostgreSQL DSN format
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set client encoding (equivalent to charset=utf8mb4 in MySQL)
    $pdo->exec("SET client_encoding TO 'UTF8'");

    // --- Fetch 5 columns from DB (PostgreSQL query)
    $stmt = $pdo->query("SELECT level_0, level_1, level_2, level_3, url FROM mcm_india ORDER BY level_1, level_2, level_3");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- Build hierarchy and count occurrences
    $hierarchy = [];
    $levelCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0];
    $pathCounts = [];
    $urlMap = [];

    foreach ($data as $row) {
        $levels = [trim($row['level_0']), trim($row['level_1']), trim($row['level_2']), trim($row['level_3'])];
        if (in_array('', $levels, true)) continue;

        for ($i = 0; $i < 4; $i++) {
            $curPath = implode(' > ', array_slice($levels, 0, $i + 1));
            if (!isset($pathCounts[$curPath])) $pathCounts[$curPath] = 0;
            $pathCounts[$curPath]++;
        }

        // Map url to the full path for level-4 items
        $fullPath = implode(' > ', $levels);
        $urlMap[$fullPath] = trim($row['url']);

        $cur =& $hierarchy;
        foreach ($levels as $level) {
            if (!isset($cur[$level])) $cur[$level] = [];
            $cur =& $cur[$level];
        }
    }

    // --- Count nodes per level recursively
    function countLevels($hierarchy, &$counts, $lvl = 1) {
        foreach ($hierarchy as $name => $children) {
            $counts[$lvl]++;
            if (!empty($children) && $lvl < 4) {
                countLevels($children, $counts, $lvl + 1);
            }
        }
    }
    countLevels($hierarchy, $levelCounts);

    // --- Define a color palette for level-2 nodes directly in RGBA (opacity 1.0)
    $level2Colors = [
        'rgba(104,199,35,0.80)',    // green
        'rgba(242,89,34,0.80)',     // red
        'rgba(4,11,140,0.80)',      // blue
        'rgba(254,185,36,0.80)',    // yellow
        'rgba(171,71,188,0.80)',    // purple
        'rgba(0,172,193,0.80)',     // teal
        'rgba(244,81,30,0.80)',     // orange
        'rgba(126,87,194,0.80)',    // violet
        'rgba(192,202,51,0.80)',    // lime
        'rgba(141,110,99,0.80)',    // brown
        // Add more colors if needed
    ];

    // --- Build chart data recursively with color property and opacity
    function buildChartData($tree, $counts, $parentId = '', $parentName = '', $level = 0, $parentNode = null, $parentColor = null) {
        global $urlMap, $level2Colors;
        $result = [];
        if ($level >= 4) return $result;
        $index = 0;
        foreach ($tree as $name => $children) {
            $index++;
            $id = $parentId ? $parentId . '.' . $index : $level . '.' . $index;
            $fullPath = $parentName ? $parentName . ' > ' . $name : $name;
            $count = $counts[$fullPath] ?? 1;

            $truncatedName = strlen($name) > 8 ? substr($name, 0, 8) . '...' : $name;

            // Color assignment logic with opacity
            if ($level == 0) {
                $color = 'rgba(255,255,255,1.0)'; // Level-1 (center) white
            } elseif ($level == 1) {
                // Level-2: assign unique color from palette, opacity 1.0
                $color = $level2Colors[($index - 1) % count($level2Colors)];
            } elseif ($level == 2) {
                // Level-3: inherit parent color, reduce opacity to 0.85
                if (preg_match('/rgba\((\d+),(\d+),(\d+),([0-9.]+)\)/', $parentColor, $matches)) {
                    $color = "rgba({$matches[1]},{$matches[2]},{$matches[3]},0.65)";
                } else {
                    $color = $parentColor;
                }
            } else {
                // Level-4+: inherit parent color, reduce opacity to 0.70
                if (preg_match('/rgba\((\d+),(\d+),(\d+),([0-9.]+)\)/', $parentColor, $matches)) {
                    $color = "rgba({$matches[1]},{$matches[2]},{$matches[3]},0.40)";
                } else {
                    $color = $parentColor;
                }
            }

            $node = [
                'id' => $id,
                'parent' => $parentId,
                'name' => $name . " ({$count})",
                'originalName' => $name,
                'truncatedName' => $truncatedName,
                'count' => $count,
                'level' => $level + 1,
                'isCenter' => 0,
                'parentNode' => $parentNode,
                'color' => $color // <-- Add color property
            ];

            if (empty($children) || $level == 3) {
                $node['value'] = $count;
                $node['isLeaf'] = true;
                $node['originalPath'] = $fullPath;
                // Add url for leaf nodes
                if (isset($urlMap[$fullPath])) {
                    $node['url'] = $urlMap[$fullPath];
                }
            }

            $result[] = $node;
            if (!empty($children)) {
                $result = array_merge($result, buildChartData($children, $counts, $id, $fullPath, $level + 1, $node, $color));
            }
        }
        return $result;
    }

    $chartData = buildChartData($hierarchy, $pathCounts);
    $jsonData = json_encode($chartData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $totalRecords = count($data);
    
    // Calculate total count for center display
    $totalCount = 0;
    foreach ($pathCounts as $path => $count) {
        if (strpos($path, ' > ') === false) { // Only count level 1 items
            $totalCount += $count;
        }
    }
    
} catch (Exception $e) {
    die("DB error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Medical Countermeasures (MCMs) India</title>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/sunburst.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<style>
   * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(166deg, #eaea66 0%, #e7efee 100%);
    min-height: 100vh;
    line-height: 1.6;
  }

  /* Header Menu */
  .header-menu {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
    position: sticky;
    top: 0;
    z-index: 1000;
  }

  .menu-container {
    max-width: 1400px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 32px;
    height: 70px;
  }

  .logo {
    font-size: 24px;
    font-weight: 800;
    color: #667eea;
    text-decoration: none;
    float: left;
  }

  .nav-menu {
    display: flex;
    list-style: none;
    gap: 40px;
  }

  .nav-menu a {
    text-decoration: none;
    color: #4a5568;
    font-weight: 500;
    font-size: 16px;
    transition: color 0.3s ease;
    position: relative;
  }

  .nav-menu a:hover {
    color: #667eea;
  }

  .nav-menu a::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background: #667eea;
    transition: width 0.3s ease;
  }

  .nav-menu a:hover::after {
    width: 100%;
  }

  .menu-toggle {
    display: none;
    background: none;
    border: none;
    font-size: 24px;
    color: #4a5568;
    cursor: pointer;
  }

  /* Hero Slider */
  .hero-slider {
    position: relative;
    height: 600px;
    overflow: hidden;
    margin-bottom: 0;
  }

  .slide {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    transition: opacity 1s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-align: center;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
  }

  .slide.active {
    opacity: 1;
  }

  .slide1 {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.8), rgba(118, 75, 162, 0.8)), 
                url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80');
    background-size: cover;
    background-position: center;
  }

  .slide2 {
    background: linear-gradient(135deg, rgba(67, 56, 202, 0.8), rgba(139, 92, 246, 0.8)), 
                url('https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80');
    background-size: cover;
    background-position: center;
  }

  .slide3 {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.8), rgba(52, 211, 153, 0.8)), 
                url('https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80');
    background-size: cover;
    background-position: center;
  }

  /* ICMR Logo overlay */
  .icmr-logo {
    position: absolute;
    top: 30px;
    right: 30px;
    width: 120px;
    height: auto;
    opacity: 0.9;
    z-index: 5;
  }

  .slide-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.3);
    z-index: 1;
  }

  .slide-content {
    position: relative;
    z-index: 2;
    max-width: 800px;
    padding: 0 20px;
  }

  .slide-content h2 {
    font-size: 48px;
    font-weight: 800;
    margin-bottom: 20px;
  }

  .slide-content p {
    font-size: 20px;
    font-weight: 400;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
  }

  .slider-nav {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 15px;
  }

  .slider-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .slider-dot.active {
    background: white;
  }

  /* Main Content */
  .main-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 32px;
  }

  .content-wrapper {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 24px;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(10px);
    margin: 60px 0;
    overflow: hidden;
    min-height: 700px;
  }

  .content-inner {
    display: flex;
    min-height: 700px;
  }

  /* About Section */
  .about-section {
    float: left;
    width: 40%;
    padding: 40px;
    border-right: 1px solid rgba(102, 126, 234, 0.1);
  }

  .about-section h2 {
    font-size: 25px;
    font-weight: 700;
    color: #2d3748;
    margin-bottom: 24px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .about-section h3 {
    font-size: 20px;
    font-weight: 600;
    color: #4a5568;
    margin: 32px 0 16px 0;
  }

  .about-section p {
    color: #718096;
    margin-bottom: 20px;
    text-align: justify;
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin: 32px 0;
  }

  .stat-card {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 24px;
    border-radius: 16px;
    text-align: center;
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
  }

  .stat-card .number {
    font-size: 28px;
    font-weight: 800;
    margin-bottom: 8px;
  }

  .stat-card .label {
    font-size: 14px;
    opacity: 0.9;
  }

  .features-list {
    list-style: none;
    margin: 24px 0;
  }

  .features-list li {
    padding: 12px 0;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .features-list li:last-child {
    border-bottom: none;
  }

  .features-list i {
    color: #667eea;
    font-size: 16px;
  }

  /* Chart Section */
  .chart-section {
    float: left;
    width: 60%;
    position: relative;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.02), rgba(118, 75, 162, 0.02));
  }

  .chart-header {
    padding: 40px 32px 20px 32px;
    text-align: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    position: relative;
  }

  .chart-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    /*background: linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%); */
  }

  .chart-header h2 {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
    position: relative;
    z-index: 1;
  }

  .chart-header p {
    margin: 8px 0 0 0;
    font-size: 12px;
    font-weight: 400;
    opacity: 0.9;
    position: relative;
    z-index: 1;
  }

  #container {
    width: 100%;
    background: white;
  }

  .chart-container {
    position: relative;
  }

  .center-info {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    pointer-events: none;
    z-index: 10;
    transition: all 0.3s ease;
  }

  .center-title {
    font-size: 20px;
    font-weight: 900;
    color: black !important;
    margin: 0;
    opacity: 0.8;
  }

  .center-name {
    font-size: 14px;
    font-weight: 800;
    color: #4a5568;
    margin: 4px 0;
    max-width: 200px;
    word-wrap: break-word;
  }

  .center-count {
    font-size: 20px;
    font-weight: 800;
    color: black !important;
    margin: 4px 0 0 0;
  }

  /* Footer */
  .footer {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    margin-top: 60px;
  }

  .footer-content {
    max-width: 1400px;
    margin: 0 auto;
    padding: 60px 32px 32px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 40px;
  }

  .footer-section h3 {
    font-size: 20px;
    font-weight: 700;
    color: #2d3748;
    margin-bottom: 20px;
  }

  .footer-section p, .footer-section li {
    color: #718096;
    margin-bottom: 12px;
  }

  .footer-section ul {
    list-style: none;
  }

  .footer-section a {
    color: #718096;
    text-decoration: none;
    transition: color 0.3s ease;
  }

  .footer-section a:hover {
    color: #667eea;
  }

  .footer-bottom {
    border-top: 1px solid #e2e8f0;
    padding: 32px;
    text-align: center;
    color: #718096;
    font-size: 14px;
  }

  .social-links {
    display: flex;
    gap: 16px;
    margin-top: 16px;
  }

  .social-links a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: transform 0.3s ease;
  }

  .social-links a:hover {
    transform: translateY(-2px);
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .nav-menu {
      display: none;
    }

    .menu-toggle {
      display: block;
    }

    .hero-slider {
      height: 400px;
    }

    .icmr-logo {
      width: 80px;
      top: 20px;
      right: 20px;
    }

    .content-inner {
      flex-direction: column;
    }
  .about-section {
    float: left;
    width: 100%;
	border-right: none;
    border-bottom: 1px solid rgba(102, 126, 234, 0.1);
  }
  .chart-section {
    float: left;
    width: 100%;
  }

    .slide-content h2 {
      font-size: 32px;
    }

    .slide-content p {
      font-size: 16px;
    }

    .stats-grid {
      grid-template-columns: 1fr;
    }

    .footer-content {
      grid-template-columns: 1fr;
      gap: 30px;
    }

    .chart-header {
      padding: 30px 20px 15px 20px;
    }

    #container {
      height: 500px !important;
    }
  }

  @media (max-width: 480px) {
    .main-container {
      padding: 0 16px;
    }
  .about-section {
    float: left;
    width: 100%;
  }
  .chart-section {
    float: left;
    width: 100%;
  }
    .about-section, .chart-section {
      padding: 20px;
    }

    .slide-content h2 {
      font-size: 24px;
    }

    .slide-content p {
      font-size: 14px;
    }
  }
  .highcharts-credits{display:none;}</style>
</head>
<body>
  <!-- Header Menu -->
  <header class="header-menu">
    <div class="menu-container">
      <a href="#" class="logo"><img src="https://etimg.etb2bimg.com/photo/66649056.cms" style="float: left; width: 175px;" alt="ICMR Logo"></a>
      <nav>
        <ul class="nav-menu">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#data">Data Analysis</a></li>
          <li><a href="#insights">Insights</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
      <button class="menu-toggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>
  </header>

  <!-- Hero Slider -->
  <section class="hero-slider" id="home">
    <div class="slide slide1 active">
      <div class="slide-overlay"></div>

      <div class="slide-content">
        <h2>Medical Countermeasures (MCMs) India</h2>
        <p>Comprehensive visualization and analysis of hierarchical data structures with interactive exploration capabilities powered by ICMR research standards</p>
      </div>
    </div>
    <div class="slide slide2">
      <div class="slide-overlay"></div>

      <div class="slide-content">
        <h2>Medical Countermeasures (MCMs) India</h2>
        <p>Explore multi-level data relationships through intuitive drill-down functionality and dynamic visualizations following ICMR data standards</p>
      </div>
    </div>
    <div class="slide slide3">
      <div class="slide-overlay"></div>
      <div class="slide-content">
        <h2>Medical Countermeasures (MCMs) India</h2>
        <p>Get instant access to data patterns, trends, and detailed breakdowns across all hierarchical levels with ICMR-compliant analytics</p>
      </div>
    </div>
    <div class="slider-nav">
      <div class="slider-dot active" data-slide="0"></div>
      <div class="slider-dot" data-slide="1"></div>
      <div class="slider-dot" data-slide="2"></div>
    </div>
  </section>

  <!-- Main Content -->
  <div class="main-container">
    <div class="content-wrapper">
      <div class="content-inner">
        <!-- About Section -->
        <div class="about-section" id="about">
          <h2>About MCM</h2>
          <p>
            Medical countermeasures (MCMs) are crucial for national preparedness and response to public health emergencies. These MCM include vaccines, diagnostics and therapeutics. This landscape analysis is an attempt to map existing efforts in pipeline or already validated MCM across different sectors, institutes and organisations of the country. It is an outline of current status of MCMs in India based on inputs received so far from various stakeholders across the country. .
          </p>
          
        </div>

        <!-- Chart Section -->
        <div class="chart-section" id="data">
          <div class="chart-header">
            <h2>Data Visualization</h2>
            <p>Interactive Sunburst Chart - Click to Explore</p>
          </div>
          
          <div class="chart-container">
            <div id="container"></div>
            <div class="center-info" id="centerInfo">
              <div class="center-title"></div>
              <div class="center-name" id="centerName"></div>
              <div class="center-count" id="centerCount"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div id="contact" class="footer-content">
      <div class="footer-section">
        <h3>ICMR India</h3>
        <p>Comprehensive data analysis and visualization platform providing insights into hierarchical data structures.</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
      
      <div class="footer-section">
        <h3>Quick Links</h3>
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#data">Data Analysis</a></li>
          <li><a href="#insights">Insights</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
      
      <div class="footer-section">
        <h3>Features</h3>
        <ul>
          <li><a href="#">Interactive Charts</a></li>
          <li><a href="#">Data Export</a></li>
          <li><a href="#">Real-time Analysis</a></li>
          <li><a href="#">Custom Reports</a></li>
          <li><a href="#">API Access</a></li>
        </ul>
      </div>
      
      <div class="footer-section">
        <h3>Contact Info</h3>
        <p><i class="fas fa-envelope"></i>  icmrhqds@icmr.org</p>
        <p><i class="fas fa-phone"></i> +91-11-26588895 | +91-11-26588980</p>
        <p><i class="fas fa-map-marker-alt"></i>  V. Ramalingaswami Bhawan, P.O. Box No. 4911, Ansari Nagar, New Delhi - 110029, India</p>
      </div>
    </div>
    
    <div class="footer-bottom">
      <p>&copy; 2025 Indian Council of Medical Research, New Delhi</p>
    </div>
  </footer>

<script>
// Slider functionality
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.slider-dot');

setTimeout(() => {
  updateCenterInfo();
}, 100);

function showSlide(n) {
  slides[currentSlide].classList.remove('active');
  dots[currentSlide].classList.remove('active');
  
  currentSlide = (n + slides.length) % slides.length;
  
  slides[currentSlide].classList.add('active');
  dots[currentSlide].classList.add('active');
}

function nextSlide() {
  showSlide(currentSlide + 1);
}

// Auto-advance slides
setInterval(nextSlide, 5000);

// Dot navigation
dots.forEach((dot, index) => {
  dot.addEventListener('click', () => showSlide(index));
});

// Chart data and functionality
const data = <?php echo $jsonData; ?>;
const pathCounts = <?php echo json_encode($pathCounts); ?>;

// Updated color palette to match the reference image
const levelColors = [
  '#ffffffff', // Level 1 - Red/coral color for outer ring
  '#4285F4', // Level 2 - Blue color for middle ring  
  '#34A853', // Level 3 - Green color for inner ring
  '#FBBC04'  // Level 4 - Yellow/orange for center
];

const chart = Highcharts.chart('container', {
  chart: { 
    height: 600,
    backgroundColor: 'transparent',
    style: {
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    },
    events: {
      drilldown: function(e) {
        setTimeout(() => {
          updateCenterInfo(e.point);
        }, 100);
      },
      drillup: function(e) {
        setTimeout(() => {
          const currentLevel = this.series[0].rootNode;
          if (currentLevel && currentLevel !== '') {
            // Find the current root point
            const rootPoint = this.series[0].points.find(point => point.id === currentLevel);
            updateCenterInfo(rootPoint);
          } else {
            updateCenterInfo();
          }
        }, 100);
      }
    }
  },
  
  title: { text: '' },
  
  plotOptions: {
    sunburst: {
      animation: {
        duration: 1000
      },
      borderWidth: 2,
      borderColor: 'rgba(255, 255, 255, 0.9)',
      states: {
        hover: {
          brightness: 0.1,
          borderColor: '#ffffff',
          borderWidth: 3
        }
      },
      point: {
        events: {
          click: function(e) {
            // Open info page in new tab for leaf nodes (level-4)
            if (this.isLeaf && this.url) {
              //window.open(this.url, '_blank');
              window.open(this.url, "_self");
            } else {
              // Update center info when clicking on a point
              setTimeout(() => {
                console.log(this);
                updateCenterInfo(this);
              }, 500);
            }
          }
        }
      }
    }
  },
  
  series: [{
    type: 'sunburst',
    data: data,
    allowTraversingTree: true,
    cursor: 'pointer',
    
    dataLabels: {
      format: '{point.truncatedName}<br><span style="font-size: 10px; opacity: 0.9;">{point.count}</span>',
      filter: { 
        property: 'innerArcLength', 
        operator: '>', 
        value: 12 
      },
      style: { 
        fontSize: '12px',  
        color: '#fff', 
        textOutline: '1px rgba(0,0,0,0.5)',
        fontWeight: '600'
      },
      rotation: 0
    },
    
    levels: [
      { 
        level: 1, 
        color: levelColors[0], // Red/coral for level 1
        colorVariation: {
          key: 'brightness',
          to: -0.2
        },
        dataLabels: { 
          style: { 
            fontSize: '13px', 
            fontWeight: '700', 
            color: '#000000ff'
          } 
        }
      },
      { 
        level: 2, 
        color: levelColors[1], // Blue for level 2
        colorVariation: {
          key: 'brightness',
          to: -0.15
        },
        dataLabels: { 
          style: { 
            fontSize: '12px', 
            fontWeight: '600', 
            color: '#fff',
            textOutline: '1px rgba(0,0,0,0.5)'
          } 
        }
      },
      { 
        level: 3, 
        color: levelColors[2], // Green for level 3
        colorVariation: {
          key: 'brightness',
          to: -0.1
        },
        dataLabels: { 
          style: { 
            fontSize: '11px', 
            fontWeight: '600', 
            color: '#fff',
            textOutline: '1px rgba(0,0,0,0.4)'
          } 
        }
      },
      { 
        level: 4, 
        color: levelColors[3], // Yellow/orange for level 4
        colorVariation: {
          key: 'brightness',
          to: -0.05
        },
        dataLabels: { 
          style: { 
            fontSize: '10px', 
            fontWeight: '600',
            color: '#2d3748',
            textOutline: '1px rgba(255,255,255,0.8)'
          } 
        }
      }
    ]
  }],
  
  tooltip: {
    headerFormat: '',
    pointFormat: `
      <div style="text-align:center;padding:15px;background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);border-radius:8px;color:white;">
        <div style="font-size:12px;font-weight:700;margin-bottom:8px;">{point.originalName}</div>
        <div style="font-size:14px;font-weight:800;opacity:0.9;">Count: {point.count}</div>
        <div style="font-size:12px;opacity:0.7;margin-top:4px;">Click to drill down</div>
        {#if point.originalPath}<div style="font-size:12px;opacity:0.8;margin-top:8px;border-top:1px solid rgba(255,255,255,0.3);padding-top:8px;">Path: {point.originalPath}</div>{/if}
      </div>
    `,
    backgroundColor: 'transparent',
    borderWidth: 0,
    borderRadius: 12,
    shadow: {
      color: 'rgba(0,0,0,0.2)',
      offsetX: 0,
      offsetY: 4,
      opacity: 0.3,
      width: 10
    },
    useHTML: true
  },
  
  responsive: {
    rules: [{
      condition: {
        maxWidth: 768
      },
      chartOptions: {
        chart: {
          height: 500
        },
        series: [{
          dataLabels: {
            style: {
              fontSize: '10px'
            }
          }
        }]
      }
    }]
  }
});

function updateCenterInfo(pointObj) {
  
  const centerTitle = document.getElementById('centerInfo').querySelector('.center-title');
  const centerName = document.getElementById('centerName');
  const centerCount = document.getElementById('centerCount');

  if(!pointObj){
    console.log("called for the first time");

    // Find the first level-1 item in the data array
    firstLevel1 = Array.isArray(data) ? data.find(item => item.level === 1) : null;
    if (firstLevel1) {
      centerTitle.textContent = firstLevel1.originalName || ''
      centerCount.textContent = firstLevel1.count || '';
      firstLevel1.isCenter = 1;
      console.log("The MCM's isCenter is modified to : ", firstLevel1.isCenter);
      console.log(firstLevel1);
    } else {
      centerTitle.textContent = '';
      centerCount.textContent = '';
    }
    return;
  }

  const point = pointObj.point;
  const isCenter = point.isCenter;

  // Changing the center title for the Drill-Up operation (i.e. user clicked in the center)
  if(isCenter || point.level==1){
    console.log("This is a drill-up operation");
    if(!pointObj.parentNode){
      point.isCenter = 1;
      pointObj.isCenter = 1;
    }
    
    centerTitle.textContent = pointObj.parentNode.originalName || '';
    centerName.textContent = pointObj.parentNode.originalPath || '';
    centerCount.textContent = pointObj.parentNode.count || '';

    pointObj.parentNode.isCenter = true;

    point.isCenter = false;
  }

  // Changing the center title for the Drill-down operation (i.e. user clicked in the ring)
  else{
    console.log("This is a drill-down operation");
    centerTitle.textContent = point.originalName || '';
    centerName.textContent = point.originalPath || '';
    centerCount.textContent = point.count || '';

    pointObj.parentNode.isCenter = false;

    point.isCenter = true;
  }

  // // For level 1, show "MCM"
  // if (point.level === 1) {
  //   centerTitle.textContent = '';
  //   centerTitle.textContent = 'MCM';
  //   centerName.textContent = point.originalName || '';
  //   centerCount.textContent = point.count || '';
  //   console.log('Center title changed to MCM');
  // }
  
  // // For level 2 or above, show the item name
  // else {
  //   centerTitle.textContent = point.originalName || '';
  //   centerName.textContent = point.originalPath || '';
  //   centerCount.textContent = point.count || '';
  //   console.log('Center title changed to', point.originalName);
  // }
}

function updateCenterInfo2(pointObj){
  const centerTitle = document.getElementById('centerInfo').querySelector('.center-title');
  const centerName = document.getElementById('centerName');
  const centerCount = document.getElementById('centerCount');

  if(!pointObj){
    console.log("called for the first time");

    // Find the first level-1 item in the data array
    firstLevel1 = Array.isArray(data) ? data.find(item => item.level === 1) : null;
    if (firstLevel1) {
      centerTitle.textContent = firstLevel1.originalName || ''
      centerCount.textContent = firstLevel1.count || '';
      firstLevel1.isCenter = 1;
      console.log("The MCM's isCenter is modified to : ", firstLevel1.isCenter);
      console.log(firstLevel1);
    } else {
      centerTitle.textContent = '';
      centerCount.textContent = '';
    }
    return;
  }

  point = pointObj.level;

  if(point.level==1){
    return;
  }

  if (point.level==2){
    if(!point.isCenter){
      centerTitle.textContent = point.originalName || '';
      centerName.textContent = point.originalPath || '';
      centerCount.textContent = point.count || '';

      pointObj.parentNode.isCenter = false;

      pointObj.point.isCenter = true;

      return;
    }

    enterTitle.textContent = point.originalName || '';
    centerName.textContent = point.originalPath || '';
    centerCount.textContent = point.count || '';

    pointObj.parentNode.isCenter = true;

    pointObj.point.isCenter = false;
  }

}
</script>
</body>
</html>
