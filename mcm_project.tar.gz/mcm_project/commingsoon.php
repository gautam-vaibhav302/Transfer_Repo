<?php
// coming-soon.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Coming Soon</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <style>
    /* Reset body */
    body {
      margin: 0;
      height: 100vh;
      overflow: hidden;
      background: linear-gradient(135deg, #481bae, #14aafd 70%) fixed;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      font-family: 'Montserrat', sans-serif;
      position: relative;
    }

    /* Animated background particles */
    .bubbles {
      position: absolute;
      width: 100vw;
      height: 100vh;
      z-index: 0;
      overflow: hidden;
      top: 0;
      left: 0;
      pointer-events: none;
    }
    .bubble {
      position: absolute;
      bottom: -100px;
      width: 40px;
      height: 40px;
      background: rgba(255,255,255,0.15);
      border-radius: 50%;
      animation: rise 10s linear infinite;
      filter: blur(1px);
    }
    @keyframes rise {
      0% {
        transform: translateY(0) scale(1);
        opacity: 0.7;
      }
      50% {
        opacity: 1;
      }
      100% {
        transform: translateY(-110vh) scale(1.3);
        opacity: 0;
      }
    }

    /* 3D Text effect */
    .coming-soon {
      position: relative;
      z-index: 1;
      font-size: 4em;
      font-weight: bold;
      color: #fff;
      letter-spacing: 0.08em;
      text-align: center;
      perspective: 600px;
      text-shadow:
        0 2px 10px #1a203a99,
        2px 3px 0 #14aafd,
        4px 6px 2px rgba(20,170,253,0.18),
        1px 1px 3px #1a203a;
      animation: float 2.5s ease-in-out infinite alternate;
      /* Extra layer for 3D look */
    }
    .coming-soon::before {
      content: "Coming Soon";
      position: absolute;
      left: 12px;
      top: 12px;
      color: #1a203a;
      opacity: 0.4;
      filter: blur(1px);
      z-index: -1;
      transform: skewY(4deg) scale(1.03) rotateX(-18deg);
      text-shadow: 0 1px 20px #000;
    }
    @keyframes float {
      from { transform: translateY(0) rotateX(12deg); }
      to { transform: translateY(-24px) rotateX(16deg); }
    }
  </style>
</head>
<body>

<div class="bubbles">
  <?php
    // Random bubble elements for animation
    for ($i = 0; $i < 24; $i++) {
      $left = rand(0, 100);
      $delay = rand(0, 9000)/1000;
      $size = rand(20, 45);
      echo "<div class='bubble' style='
        left: {$left}vw;
        width: {$size}px;
        height: {$size}px;
        animation-delay: {$delay}s;
        opacity: " . (rand(40, 90)/100) . ";
      '></div>";
    }
  ?>
</div>

<div class="coming-soon">Coming Soon</div>

</body>
</html>
