﻿


<?php
// Database configuration
$host = '127.0.0.1';  // or 'localhost'
$port = '5432';
$dbname = 'mcm_database';
$username = 'postgres';
$password = 'postgres';

// Optional: Set timezone
date_default_timezone_set('Asia/Kolkata');

// Optional: Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>


