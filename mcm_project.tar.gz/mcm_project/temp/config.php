<?php
// Database configuration
$host = '127.0.0.1';  // or 'localhost'
$port = '5432';
$dbname = 'mcm_database';
$username = 'postgres';
$password = 'postgres';

// Optional: Set timezone
date_default_timezone_set('Asia/Kolkata');

// Optional: Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    echo "✅ Connected to PostgreSQL successfully!";
} catch (PDOException $e) {
    echo "❌ Connection failed: " . $e->getMessage();
}
?>
